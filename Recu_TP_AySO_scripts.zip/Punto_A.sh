#!/usr/bin/env bash
set -e
sudo mkdir -p /datos/{textos,libros,revistas,videos/{peliculas,series}}

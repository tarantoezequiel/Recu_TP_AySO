# Recu_TP_AySO

**Alumno:** Ezequiel Taranto  
**Comisión:** 116  
**Turno:** Mañana  

Repositorio correspondiente al Trabajo Práctico Recuperatorio de Arquitectura y Sistemas Operativos.  
Incluye los puntos A a F, más el historial de comandos ejecutados.
